class Craft(object):
    """For all the crafts in etsy. Will contain:
    title
    name of Craft person
    product code
    price
    number of self in stock
    and a boolean if a craft needs to be reordered"""

    print("User options are as follows:")
    print("You may add a new craft to the store ['a']")
    print("You may add inventory for an existing craft ['u']")
    print("You may remove inventory of an existing craft and report the cost ['r']")
    print("You may compute the total value of all current inventory in the store ['v']")
    print("You may print out information about all crafts that need to be reordered ['o']")
    print("You may quit the program ['q']")

    def __init__(self, title, name, productCode, priceOfcraft, number, orderingThreshold):
        self.title = title
        self.name = name
        self.productCode = productCode
        self.priceOfcraft = priceOfcraft
        self.number = number
        self.orderingThreshold= orderingThreshold

#using setters and getters
    def setNumber(self, newStock):
        self.number = newStock
    def getTitle(self):
        return self.title
    def getname(self):
        return self.name
    def getProductCode(self):
        return str(self.productCode)
    def getPriceOfcraft(self):
        return int(self.priceOfcraft)
    def getNumber(self):
        return int(self.number)
    def getOrderingThreshold(self):
        return int(self.orderingThreshold)

    def __lt__(self, number, threshold):
        if self.getNumber() <= self.getOrderingThreshold():
            return True
        else:
            return False
