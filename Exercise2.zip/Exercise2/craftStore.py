from Craft import Craft

def __gettingInput__(craftList):
    title = input("User must enter craft title: ")
    getname = input("Enter Craft person name: ")
    productCode = input("User must enter the product code: ")
    priceOfcraft = float(input("User must enter the price of the craft: "))
    #integer value needed for number of self in stock
    numberInStock = int(input("User must enter number crafts they want: "))
    orderingThreshold = int(input("User must enter the ordering threshold: "))
    addAcraft = Craft(title, getname, productCode, priceOfcraft, numberInStock, orderingThreshold)
    craftList.append(addAcraft)

def addingInventory(craftList):
    craftCode=input("Enter the craft code: ")
    craftFound = False
    for craft in craftList:
        if(craft.getProductCode()==str(craftCode)):
            craftFound =True
            index=craftList.index(craft)

    if(craftFound):
        num=input("Number of crafts you want to add: ")
        craft.setNumber(craft.getNumber()+int(num))
    else:
        print("Error. No such code. ")

def removingInventory(craftList):

    craftCode=input("Enter the craft code: ")
    craftFound=False
    for craft in craftList:
        if(craft.getProductCode()==str(craftCode)):
            craftFound=True
            index=craftList.index(craft)

    if(craftFound):
        num=input("Number of crafts you want to remove: ")
        craft.setNumber(craft.getNumber()-int(num))
    else:
        print("Error. No such code. ")

def currentInventory(craftList):
   sum=0
   for craft in craftList:
       sum+=int(craft.getNumber())*(craft.getPriceOfcraft())
   print(sum)

def refillInventory(craftList):
    for craft in craftList:
        if(craft.__lt__(craft.getOrderingThreshold(), craft.getPriceOfcraft())):
          print(craft.getTitle())
          print(craft.getname())
          print(craft.getPriceOfcraft())
          print(craft.getProductCode())
          print(craft.getOrderingThreshold())
          print(craft.getNumber())

def main():
    craftList = []

    for i in range(1,6):
        userInput=input("What do you want to do? ['a','u','r','v','o']")
        if(userInput=='a'):
            __gettingInput__(craftList)
        elif(userInput == 'u'):
            addingInventory(craftList)
        elif(userInput == 'r'):
            removingInventory(craftList)
        elif(userInput =='v'):
            currentInventory(craftList)
        elif(userInput == 'o'):
            refillInventory(craftList)

main()
